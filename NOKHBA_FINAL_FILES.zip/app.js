"use strict";

/* NOKHBA | Premium Products Display Engine
   Version 6.0
*/
(() => {
  const $ = id => document.getElementById(id);
  const grid = $("products");
  const searchInput = $("productSearch");
  const categoryFilter = $("categoryFilter");
  const storeFilter = $("storeFilter");
  const resultCount = $("resultCount");
  const emptyMessage = $("emptyMessage");
  const resetButton = $("resetFilters");

  if (!grid) {
    console.error("NOKHBA: products container not found.");
    return;
  }

  const categoryNames = {
    electronics: "الإلكترونيات",
    home: "المنزل والمطبخ",
    fashion: "الأزياء",
    featured: "اختيارات مميزة",
    cars: "مستلزمات السيارات",
    daily: "احتياجات يومية"
  };

  const storeNames = {
    amazon: "Amazon Egypt",
    noon: "Noon Egypt",
    jumia: "Jumia Egypt"
  };

  const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);

  function safeURL(value) {
    if (typeof value !== "string" || !value.trim()) return "";
    try {
      const u = new URL(value.trim());
      if (u.protocol !== "https:") return "";
      return u.href;
    } catch {
      return "";
    }
  }

  function normalizeStore(value) {
    const s = String(value || "").toLowerCase().trim();
    if (s.includes("amazon") || s.includes("أمازون")) return "amazon";
    if (s.includes("noon") || s.includes("نون")) return "noon";
    if (s.includes("jumia") || s.includes("جوميا")) return "jumia";
    return "";
  }

  function getAllProducts() {
    const sources = [window.AMAZON_PRODUCTS, window.NOKHBA_EXTRA_PRODUCTS];
    const map = new Map();

    sources.forEach(list => {
      if (!Array.isArray(list)) return;
      list.forEach(p => {
        if (!p || typeof p !== "object" || !String(p.name || "").trim()) return;
        const key = String(p.id || p.name).trim().toLowerCase();
        const store = normalizeStore(p.store);
        const image = safeURL(p.image);
        const url = safeURL(p.url);
        // لا نعرض منتجات بلا صورة حقيقية أو رابط شراء مباشر.
        if (!image || !url || !store) return;
        if (!map.has(key)) map.set(key, { ...p, store, image, url });
      });
    });

    return [...map.values()];
  }

  const products = getAllProducts();

  function productCard(p) {
    const name = escapeHTML(p.name);
    const description = escapeHTML(p.description || "اكتشف تفاصيل المنتج في المتجر.");
    const category = escapeHTML(categoryNames[p.category] || "اختيارات نخبة");
    const store = p.store;
    let link = p.url;

    // ضمان وضع معرّف العمولة على روابط Amazon.eg فقط.
    if (store === "amazon") {
      try {
        const u = new URL(link);
        if (u.hostname === "amazon.eg" || u.hostname.endsWith(".amazon.eg")) {
          u.searchParams.set("tag", window.NOKHBA_AFFILIATE_TAG || "ashrafdealseg-21");
          link = u.href;
        }
      } catch { return ""; }
    }

    return `
      <article class="product-card">
        <div class="product-image-container">
          <img class="product-image" src="${escapeHTML(p.image)}" alt="${name}" loading="lazy" decoding="async">
        </div>
        <div class="product-info">
          <span class="product-category">${category}</span>
          <h3>${name}</h3>
          <p>${description}</p>
          <div class="product-store-buttons">
            <a class="product-button" href="${escapeHTML(link)}" target="_blank" rel="noopener noreferrer sponsored">
              عرض المنتج في ${escapeHTML(storeNames[store] || store)}
              <span aria-hidden="true">↗</span>
            </a>
          </div>
        </div>
      </article>`;
  }

  grid.addEventListener("error", event => {
    const img = event.target;
    if (img && img.tagName === "IMG" && img.classList.contains("product-image")) {
      const container = img.closest(".product-image-container");
      if (container) container.innerHTML = '<div class="image-unavailable">الصورة غير متاحة حالياً</div>';
    }
  }, true);

  function render() {
    const q = (searchInput?.value || "").trim().toLowerCase();
    const category = categoryFilter?.value || "all";
    const store = storeFilter?.value || "all";

    const filtered = products.filter(p => {
      const text = [p.name, p.brand, p.description, p.category, p.store].filter(Boolean).join(" ").toLowerCase();
      return (!q || text.includes(q)) &&
        (category === "all" || p.category === category) &&
        (store === "all" || p.store === store);
    });

    grid.innerHTML = filtered.map(productCard).filter(Boolean).join("");
    if (resultCount) resultCount.textContent = `عدد المنتجات المتاحة: ${filtered.length}`;
    if (emptyMessage) emptyMessage.hidden = filtered.length > 0;
  }

  searchInput?.addEventListener("input", render);
  categoryFilter?.addEventListener("change", render);
  storeFilter?.addEventListener("change", render);

  resetButton?.addEventListener("click", () => {
    if (searchInput) searchInput.value = "";
    if (categoryFilter) categoryFilter.value = "all";
    if (storeFilter) storeFilter.value = "all";
    render();
  });

  document.querySelectorAll(".category-card").forEach(card => {
    card.addEventListener("click", () => {
      const category = card.dataset.category;
      if (categoryFilter && category) categoryFilter.value = category;
      render();
    });
  });

  const menuBtn = $("menuBtn");
  const nav = $("mainNav");
  menuBtn?.addEventListener("click", () => {
    if (!nav) return;
    const opened = nav.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", String(opened));
  });
  nav?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    nav.classList.remove("open");
    menuBtn?.setAttribute("aria-expanded", "false");
  }));

  render();
  console.log(`NOKHBA 6.0: ${products.length} verified products loaded.`);
})();
