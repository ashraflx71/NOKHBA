"use strict";

/* NOKHBA | قاعدة المنتجات المؤكدة
   Affiliate tag: ashrafdealseg-21
   لا تضف منتجاً قبل التأكد من رابط الشراء والصورة.
*/
(() => {
  const TAG = "ashrafdealseg-21";
  const amazonLink = asin => `https://www.amazon.eg/dp/${asin}?tag=${TAG}`;

  const PRODUCTS = [
    {
      id: "sony-wh-ch520",
      name: "سماعة سوني اللاسلكية WH-CH520",
      category: "electronics",
      brand: "Sony",
      asin: "B0BS1QB15L",
      image: "https://store.sony.com.au/on/demandware.static/-/Sites-sony-master-catalog/default/dwe58091b5/images/WHCH520W/WHCH520W.png",
      price: null,
      currency: "EGP",
      description: "سماعة بلوتوث لاسلكية مع ميكروفون للمكالمات، وبطارية تصل إلى 50 ساعة وفق مواصفات الشركة.",
      url: amazonLink("B0BS1QB15L"),
      store: "amazon"
    },
    {
      id: "ninja-bn800eu",
      name: "جهاز نينجا متعدد الوظائف BN800EU",
      category: "home",
      brand: "Ninja",
      asin: "B08HSF4FY6",
      image: "https://www.emarqt.com/cdn/shop/files/NINJA-BN800EU-IMG-5.jpg?v=1714374598&width=3000",
      price: null,
      currency: "EGP",
      description: "جهاز مطبخ متعدد الوظائف لتحضير الطعام والخلط والفرم.",
      url: amazonLink("B08HSF4FY6"),
      store: "amazon"
    }
  ];

  window.AMAZON_PRODUCTS = PRODUCTS;
  window.NOKHBA_PRODUCTS = PRODUCTS;
  window.NOKHBA_AFFILIATE_TAG = TAG;
})();
